FT.manifest({
	"filename": "Bank_HOLIDAY_COBG_No_Fees_NA_RM_RM_EN_NA_970x66_P00114026.html",
	"width": 970,
	"height": 66,
	"clickTagCount": 1,
	"videos": [{ "name": "video1", "ref": "202681/BANK_CAFE_SPOT_CHECK_NA_VID_VID_EN_15_16X9_TUBK1078000H_P00103751_OLV_HD" }],
	"expand": {
		"fullscreen": false,
		"width": 970,
		"height": 250,
		"indentAcross": 0,
		"indentDown": 0
	}
});
